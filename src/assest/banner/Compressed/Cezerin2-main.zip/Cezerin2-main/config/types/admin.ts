export interface Admin {
  language: string
  apiBaseUrl: string
  apiWebSocketUrl: string
  developerMode: boolean
}
