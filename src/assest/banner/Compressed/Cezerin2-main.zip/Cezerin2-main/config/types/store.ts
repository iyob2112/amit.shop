export interface Store {
  language: string
  ajaxBaseUrl: string
}
