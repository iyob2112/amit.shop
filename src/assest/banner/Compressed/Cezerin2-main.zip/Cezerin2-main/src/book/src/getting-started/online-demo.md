## Online Demo

Single-Page Application with React server-side rendering.

SEO Friendly. Google Analytics eCommerce Tracking included.

[Online Demo Store - Plusha Theme](https://plusha.demo.chost.ansiglobal.com)

[![Cezerin Store Plusha Theme](/img/cezerin-plusha-theme.png)](https://plusha.demo.chost.ansiglobal.com)

[Online Demo Store - Default Theme](https://demo.chost.ansiglobal.com)

[![Cezerin Store Default Theme](/img/cezerin-default-theme.png)](https://demo.chost.ansiglobal.com)
[![Cezerin Store Default Theme](/img/cezerin-mobile-order-summary.png)](https://demo.chost.ansiglobal.com)

## Dashboard

Client-side dashboard use JSON Web Token (JWT) to access REST API.

[Online Demo Dashboard](https://demo.chost.ansiglobal.com/admin)

![Cezerin Dashboard](/img/cezerin-dashboard-products.png)
