## Hosting

You can use any hosting: shared hosting with ssh, VM hosting, VDS hosting, NodeJS hosting, DigitalOcean, cloud services like Heroku, Amazon AWS, Google Cloud, any...
All you need is MERN stack (MongoDB + ExpressJS + ReactJs + NodeJS), nothing special.
You can install it on virtual machine, or you can use "out of the box" services like Heroku, Google Firebase etc...

I'll use [DigitalOcean](https://m.do.co/c/a1d5495e08b2) to deploy Cezerin.

Register by this link at DigitalOcean and receive free 10\$ coupon to your account.

You can add your site for free for 2 month. 5\$ per month.
coupon code is ACTIVATE10, activate it in your profile - billing tab.
