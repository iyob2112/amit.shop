import applicationText from "./en_US.json"

export default applicationText
