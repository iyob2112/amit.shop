import CustomerDetails from "modules/customers/edit"

export default CustomerDetails
